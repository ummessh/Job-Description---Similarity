def filter_employees(employees, required_degree, min_years_experience):
    filtered = []
    for emp in employees:
        if (emp.get("Degree_Canonical") == required_degree 
            and emp.get("Years_Experience", 0) >= min_years_experience):
            filtered.append(emp)
    return filtered

# Example usage
if __name__ == "__main__":
    from scripts.load_employee_data import load_employees
    emps = load_employees()
    filtered = filter_employees(emps, "Bachelor of Science", 2)
    print(f"{len(filtered)} employees passed the strict filter")
