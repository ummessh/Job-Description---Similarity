from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import numpy as np

# Load local embedding model once
local_model = SentenceTransformer('all-MiniLM-L6-v2')

def get_embedding_local(text: str):
    return local_model.encode(text).tolist()

def rank_employees(filtered_employees, job_description, top_n=5):
    jd_embedding = np.array(get_embedding_local(job_description)).reshape(1, -1)

    ranked_list = []
    for emp in filtered_employees:
        emp_embedding = np.array(get_embedding_local(emp['Profile_Text'])).reshape(1, -1)
        score = float(cosine_similarity(jd_embedding, emp_embedding)[0][0])

        matching_skills = list(set(emp.get("Skills", [])) & set(job_description.split()))
        reasons = matching_skills[:3] if matching_skills else emp.get("Skills", [])[:3]

        ranked_list.append({
            "Employee_ID": emp["Employee_ID"],
            "Score": score,
            "Reasons": reasons
        })

    ranked_list.sort(key=lambda x: x['Score'], reverse=True)
    return ranked_list[:top_n]
