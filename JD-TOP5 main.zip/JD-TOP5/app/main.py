from fastapi import FastAPI
from pydantic import BaseModel
from scripts.load_employee_data import load_employees
from app.services.filtering import filter_employees
from app.services.similarity import rank_employees

app = FastAPI(title="Talent Filter & Matcher")

class JobRequest(BaseModel):
    job_description: str
    required_degree: str
    min_years_experience: int

@app.post("/match-job")
def match_job(req: JobRequest):
    employees = load_employees()
    filtered = filter_employees(employees, req.required_degree, req.min_years_experience)
    top_candidates = rank_employees(filtered, req.job_description)
    return top_candidates
