import json
import random
import os

# Ensure data folder exists
os.makedirs("data", exist_ok=True)

degrees = ["Bachelor of Science", "Master of Science", "PhD"]
skills_pool = ["Python", "Java", "SQL", "Tableau", "AWS", "NLP", "Machine Learning", "Agile", "DevOps", "Excel", "Data Visualization", "Customer Support Automation"]
years_exp_range = range(1, 11)

def generate_employee(emp_id):
    degree = random.choice(degrees)
    years = random.choice(years_exp_range)
    skills = random.sample(skills_pool, k=3)
    profile_text = f"{degree} graduate with {years} years experience in " + ", ".join(skills) + "."
    
    employee = {
        "Employee_ID": str(emp_id),
        "Profile_Text": profile_text,
        "Key_Credentials_Raw": f"{degree}, {years} years experience",
        "Degree_Canonical": degree,
        "Years_Experience": years,
        "Skills": skills
    }
    return employee

# Generate 50 employees
employees = [generate_employee(i) for i in range(101, 151)]

# Write to JSONL
with open("data/employees.jsonl", "w") as f:
    for emp in employees:
        f.write(json.dumps(emp) + "\n")

print("Generated 50 employees in data/employees.jsonl")
