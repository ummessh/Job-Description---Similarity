import json

def load_employees(file_path="data/employees.jsonl"):
    employees = []
    with open(file_path, "r") as f:
        for line in f:
            emp = json.loads(line.strip())
            employees.append(emp)
    return employees

if __name__ == "__main__":
    emps = load_employees()
    print(f"Loaded {len(emps)} employees")
